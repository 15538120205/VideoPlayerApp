package com.example.videoplayerapp

/**
 * 日期处理工具类
 */
object DateUtils {

    /**
     * 验证年份格式 (2位数字)
     */
    fun isValidYear(year: String): Boolean {
        return year.matches(Regex("^\\d{2}$"))
    }

    /**
     * 验证月日格式 (MMDD)
     */
    fun isValidMonthDay(monthDay: String): Boolean {
        if (!monthDay.matches(Regex("^\\d{4}$"))) {
            return false
        }
        val month = monthDay.substring(0, 2).toInt()
        val day = monthDay.substring(2, 4).toInt()
        return month in 1..12 && day in 1..31
    }

    /**
     * 验证数字格式 (3位数字)
     */
    fun isValidNumber(number: String): Boolean {
        return number.matches(Regex("^\\d{3}$"))
    }

    /**
     * 日期加一天
     * @param monthDay MMDD 格式的月日
     * @return 加一天后的月日 (MMDD 格式)
     */
    fun addOneDay(monthDay: String): String {
        var month = monthDay.substring(0, 2).toInt()
        var day = monthDay.substring(2, 4).toInt()

        // 月份的天数
        val daysInMonth = mapOf(
            1 to 31, 2 to 29, 3 to 31, 4 to 30, 5 to 31, 6 to 30,
            7 to 31, 8 to 31, 9 to 30, 10 to 31, 11 to 30, 12 to 31
        )

        day += 1

        if (day > (daysInMonth[month] ?: 31)) {
            day = 1
            month += 1
            if (month > 12) {
                month = 1
            }
        }

        return "${month.toString().padStart(2, '0')}${day.toString().padStart(2, '0')}"
    }

    /**
     * 生成视频链接
     * @param year 年份 (2位数字，如 26)
     * @param monthDay 月日 (MMDD 格式)
     * @param number 数字 (3位数字)
     * @return 完整的 HLS 视频链接
     */
    fun generateVideoUrl(year: String, monthDay: String, number: String): String {
        val nextMonthDay = addOneDay(monthDay)
        return "https://666.sybxpu.com/G$year$nextMonthDay$number/500kb/hls/index.m3u8"
    }
}
