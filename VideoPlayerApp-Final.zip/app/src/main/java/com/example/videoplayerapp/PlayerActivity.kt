package com.example.videoplayerapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.datasource.DefaultHttpDataSource
import com.example.videoplayerapp.databinding.ActivityPlayerBinding

/**
 * 视频播放器 Activity
 * 使用 Media3 ExoPlayer 和 StyledPlayerView 播放 HLS 视频
 */
class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private var videoUrl: String? = null
    private var year: String? = null
    private var monthDay: String? = null
    private var number: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 获取传递的参数
        videoUrl = intent.getStringExtra("videoUrl")
        year = intent.getStringExtra("year")
        monthDay = intent.getStringExtra("monthDay")
        number = intent.getStringExtra("number")

        // 初始化播放器
        initializePlayer()

        // 设置返回按钮
        binding.backButton.setOnClickListener {
            finish()
        }

        // 显示视频信息
        updateVideoInfo()
    }

    /**
     * 初始化播放器
     */
    private fun initializePlayer() {
        if (videoUrl == null) {
            showError(getString(R.string.error_play_failed))
            return
        }

        try {
            // 创建 ExoPlayer 实例
            player = ExoPlayer.Builder(this).build().apply {
                // 设置播放器到 PlayerView
                binding.playerView.player = this

                // 创建 HLS 媒体源
                val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                val hlsMediaSource = HlsMediaSource.Factory(httpDataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(videoUrl!!))

                // 设置媒体源并准备
                setMediaSource(hlsMediaSource)
                prepare()

                // 自动播放
                playWhenReady = true
            }

            // 设置播放器错误监听
            setupPlayerListener()
        } catch (e: Exception) {
            showError("${getString(R.string.error_play_failed)}: ${e.message}")
        }
    }

    /**
     * 设置播放器监听器
     */
    private fun setupPlayerListener() {
        player?.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                showError("${getString(R.string.error_play_failed)}: ${error.message}")
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    androidx.media3.common.Player.STATE_BUFFERING -> {
                        // 缓冲中
                    }
                    androidx.media3.common.Player.STATE_READY -> {
                        // 准备就绪
                    }
                    androidx.media3.common.Player.STATE_ENDED -> {
                        // 播放结束
                    }
                    else -> {}
                }
            }
        })
    }

    /**
     * 更新视频信息显示
     */
    private fun updateVideoInfo() {
        val dateInfo = "$year$monthDay"
        binding.videoDateText.text = "${getString(R.string.player_date)} $dateInfo | ${getString(R.string.player_number)} $number"
        binding.videoUrlText.text = "${getString(R.string.player_url)} $videoUrl"
    }

    /**
     * 显示错误提示
     */
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    /**
     * 释放播放器资源
     */
    private fun releasePlayer() {
        player?.let {
            it.release()
        }
        player = null
    }

    override fun onPause() {
        super.onPause()
        // 暂停播放
        player?.playWhenReady = false
    }

    override fun onResume() {
        super.onResume()
        // 恢复播放
        player?.playWhenReady = true
    }

    override fun onDestroy() {
        super.onDestroy()
        // 释放播放器资源
        releasePlayer()
    }
}
