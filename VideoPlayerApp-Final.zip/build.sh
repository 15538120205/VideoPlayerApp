#!/bin/bash

# Video Player Android - 快速构建脚本
# 用法: ./build.sh [debug|release]

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 默认构建类型
BUILD_TYPE=${1:-debug}

echo -e "${YELLOW}=== Video Player Android 构建脚本 ===${NC}"
echo -e "${YELLOW}构建类型: $BUILD_TYPE${NC}"
echo ""

# 检查 gradlew 是否存在
if [ ! -f "gradlew" ]; then
    echo -e "${RED}错误: 找不到 gradlew 文件${NC}"
    exit 1
fi

# 赋予执行权限
chmod +x gradlew

# 清除之前的构建
echo -e "${YELLOW}清除之前的构建...${NC}"
./gradlew clean

# 构建 APK
if [ "$BUILD_TYPE" = "debug" ]; then
    echo -e "${YELLOW}构建 Debug APK...${NC}"
    ./gradlew assembleDebug
    APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
elif [ "$BUILD_TYPE" = "release" ]; then
    echo -e "${YELLOW}构建 Release APK...${NC}"
    ./gradlew assembleRelease
    APK_PATH="app/build/outputs/apk/release/app-release.apk"
else
    echo -e "${RED}错误: 无效的构建类型 '$BUILD_TYPE'${NC}"
    echo "用法: ./build.sh [debug|release]"
    exit 1
fi

# 检查 APK 是否成功生成
if [ -f "$APK_PATH" ]; then
    echo -e "${GREEN}✓ 构建成功!${NC}"
    echo -e "${GREEN}APK 文件: $APK_PATH${NC}"
    
    # 显示文件大小
    SIZE=$(du -h "$APK_PATH" | cut -f1)
    echo -e "${GREEN}文件大小: $SIZE${NC}"
    
    # 提示安装
    echo ""
    echo -e "${YELLOW}下一步:${NC}"
    echo "1. 使用 adb 安装: adb install $APK_PATH"
    echo "2. 或在 Android Studio 中运行应用"
else
    echo -e "${RED}✗ 构建失败!${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}构建完成!${NC}"
