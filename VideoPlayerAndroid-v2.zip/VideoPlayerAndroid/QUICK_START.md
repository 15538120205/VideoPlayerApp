# 快速开始 - Video Player Android

## 三步生成 APK

### 方式 1：GitHub Actions（最简单 - 推荐）

1. **初始化 Git 仓库**
   ```bash
   cd /home/ubuntu/VideoPlayerAndroid
   git init
   git add .
   git commit -m "Initial commit"
   ```

2. **上传到 GitHub**
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/VideoPlayerApp.git
   git branch -M main
   git push -u origin main
   ```

3. **自动构建**
   - GitHub Actions 会自动运行
   - 访问 GitHub 仓库的 Actions 标签页
   - 下载生成的 `app-debug.apk`

**优点**：无需本地环境，完全自动化

---

### 方式 2：命令行（最快 - 需要 JDK）

1. **一键构建**
   ```bash
   cd /home/ubuntu/VideoPlayerAndroid
   ./build.sh debug
   ```

2. **获取 APK**
   ```
   APK 文件: app/build/outputs/apk/debug/app-debug.apk
   ```

**优点**：快速、简洁，适合脚本化

---

### 方式 3：Android Studio（最灵活 - 需要 IDE）

1. **打开项目**
   - 启动 Android Studio
   - File → Open → 选择 `/home/ubuntu/VideoPlayerAndroid`

2. **构建 APK**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)

3. **获取 APK**
   ```
   APK 文件: app/build/outputs/apk/debug/app-debug.apk
   ```

**优点**：图形界面，支持调试和测试

---

## 安装 APK

### 在真实设备上

```bash
# 使用 adb 安装
adb install app/build/outputs/apk/debug/app-debug.apk

# 或在 Android Studio 中运行
# Run → Run 'app'
```

### 在模拟器上

```bash
# 启动模拟器后安装
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## 项目结构

```
VideoPlayerAndroid/
├── app/                          # 应用模块
│   ├── src/main/
│   │   ├── java/                 # Kotlin 源代码
│   │   ├── res/                  # 资源文件
│   │   └── AndroidManifest.xml   # 清单文件
│   └── build.gradle.kts          # 模块配置
├── .github/workflows/            # GitHub Actions 工作流
├── gradle/                        # Gradle Wrapper
├── build.gradle.kts              # 项目配置
├── settings.gradle.kts           # 项目设置
├── gradlew                        # Gradle 脚本
├── build.sh                       # 快速构建脚本
├── BUILD_GUIDE.md                # 详细构建指南
└── README.md                      # 项目文档
```

---

## 常见问题

**Q: 需要安装什么？**
- GitHub Actions：无需安装，自动构建
- 命令行：需要 JDK 11
- Android Studio：需要 Android Studio 和 Android SDK

**Q: 构建需要多长时间？**
- 首次构建：3-5 分钟（下载依赖）
- 后续构建：1-2 分钟

**Q: APK 文件在哪里？**
- Debug：`app/build/outputs/apk/debug/app-debug.apk`
- Release：`app/build/outputs/apk/release/app-release.apk`

**Q: 如何清除构建？**
```bash
./gradlew clean
```

**Q: 如何查看构建日志？**
- Android Studio：Build 窗口
- 命令行：构建输出直接显示

---

## 下一步

1. **生成 APK**：选择上述任一方式
2. **安装应用**：在设备或模拟器上安装
3. **测试功能**：输入日期和数字，播放视频
4. **自定义**：修改源代码或资源文件

---

## 详细指南

- 完整构建指南：查看 `BUILD_GUIDE.md`
- 项目文档：查看 `README.md`
- 源代码：查看 `app/src/main/java/com/example/videoplayerapp/`

---

## 支持

如有问题，请参考：
- `BUILD_GUIDE.md` - 故障排除部分
- `README.md` - 常见问题部分
- GitHub Issues - 报告问题

祝您使用愉快！
