# 构建指南 - Video Player Android APK

本文档说明如何构建 APK 文件的三种方式。

## 前置要求

- JDK 11 或更高版本
- Android SDK（如果使用 Android Studio）
- Git（如果使用 GitHub Actions）

## 方式 1：使用 GitHub Actions（推荐 - 自动化）

### 步骤

1. **创建 GitHub 仓库**
   ```bash
   cd /home/ubuntu/VideoPlayerAndroid
   git init
   git add .
   git commit -m "Initial commit: Video Player Android App"
   git remote add origin https://github.com/YOUR_USERNAME/VideoPlayerApp.git
   git branch -M main
   git push -u origin main
   ```

2. **工作流自动执行**
   - 当您推送代码到 GitHub 时，`.github/workflows/build-apk.yml` 工作流会自动执行
   - GitHub Actions 将自动编译项目并生成 APK

3. **获取 APK**
   - 访问 GitHub 仓库的 Actions 标签页
   - 找到最新的工作流运行
   - 在 "Artifacts" 部分下载 `app-debug.apk`

### 优点
- 完全自动化，无需本地环境
- 支持持续集成/持续部署（CI/CD）
- 可以自动发布版本

## 方式 2：使用 Android Studio（推荐 - 开发）

### 步骤

1. **打开项目**
   - 启动 Android Studio
   - 选择 File → Open
   - 选择 `/home/ubuntu/VideoPlayerAndroid` 目录
   - 点击 OK

2. **等待 Gradle 同步**
   - Android Studio 会自动下载依赖并同步 Gradle
   - 这可能需要几分钟

3. **构建 APK**
   - 选择菜单 Build → Build Bundle(s) / APK(s) → Build APK(s)
   - 或使用快捷键 Ctrl+Shift+B（Windows/Linux）或 Cmd+Shift+B（Mac）

4. **查找 APK**
   - 构建完成后，会显示提示
   - APK 文件位于：`app/build/outputs/apk/debug/app-debug.apk`
   - 点击 "locate" 可直接打开文件夹

### 优点
- 图形界面，易于使用
- 可以实时调试和测试
- 支持在模拟器或真实设备上运行

## 方式 3：使用命令行（推荐 - 脚本化）

### 前置要求

- 已安装 JDK 11
- 已设置 ANDROID_HOME 环境变量（指向 Android SDK 目录）

### 步骤

1. **导航到项目目录**
   ```bash
   cd /home/ubuntu/VideoPlayerAndroid
   ```

2. **赋予 gradlew 执行权限**
   ```bash
   chmod +x gradlew
   ```

3. **构建 Debug APK**
   ```bash
   ./gradlew assembleDebug
   ```

4. **或构建 Release APK（需要签名密钥）**
   ```bash
   ./gradlew assembleRelease
   ```

5. **查找 APK**
   - Debug APK：`app/build/outputs/apk/debug/app-debug.apk`
   - Release APK：`app/build/outputs/apk/release/app-release.apk`

### 常用命令

```bash
# 清除构建
./gradlew clean

# 构建并运行测试
./gradlew build

# 仅构建 Debug APK
./gradlew assembleDebug

# 仅构建 Release APK
./gradlew assembleRelease

# 在连接的设备上安装并运行
./gradlew installDebug

# 查看所有可用任务
./gradlew tasks
```

### 优点
- 快速、高效
- 易于集成到脚本和 CI/CD 流程
- 跨平台支持

## 生成 Release APK（用于发布）

### 步骤

1. **创建签名密钥**
   ```bash
   keytool -genkey -v -keystore release.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias video_player
   ```

2. **在 `local.properties` 中配置签名信息**
   ```properties
   storeFile=../release.keystore
   storePassword=YOUR_PASSWORD
   keyAlias=video_player
   keyPassword=YOUR_KEY_PASSWORD
   ```

3. **在 `app/build.gradle.kts` 中添加签名配置**
   ```kotlin
   signingConfigs {
       release {
           storeFile = file(project.property("storeFile") as String)
           storePassword = project.property("storePassword") as String
           keyAlias = project.property("keyAlias") as String
           keyPassword = project.property("keyPassword") as String
       }
   }
   
   buildTypes {
       release {
           signingConfig = signingConfigs.release
           isMinifyEnabled = true
           proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
       }
   }
   ```

4. **构建 Release APK**
   ```bash
   ./gradlew assembleRelease
   ```

## 故障排除

### 问题：Gradle 同步失败

**解决方案**
- 检查网络连接
- 清除 Gradle 缓存：`./gradlew clean`
- 更新 Gradle：在 `build.gradle.kts` 中更新版本号

### 问题：找不到 Android SDK

**解决方案**
- 设置 ANDROID_HOME 环境变量
- 在 Android Studio 中：File → Settings → Appearance & Behavior → System Settings → Android SDK

### 问题：编译失败

**解决方案**
- 检查 JDK 版本：`java -version`
- 确保 JDK 版本为 11 或更高
- 清除构建：`./gradlew clean`
- 重新构建：`./gradlew build`

### 问题：APK 文件过大

**解决方案**
- 启用 ProGuard 混淆
- 使用 App Bundle 而不是 APK
- 移除不需要的依赖

## APK 安装

### 在真实设备上安装

1. **使用 adb 安装**
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

2. **使用 Android Studio 安装**
   - 连接设备
   - 选择 Run → Run 'app'
   - 选择目标设备

3. **手动安装**
   - 将 APK 文件复制到设备
   - 使用文件管理器打开 APK
   - 按照提示安装

### 在模拟器上安装

1. **启动模拟器**
   - 在 Android Studio 中：AVD Manager → 启动模拟器

2. **安装 APK**
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

## 验证 APK

### 检查 APK 信息

```bash
# 使用 aapt 查看 APK 信息
aapt dump badging app/build/outputs/apk/debug/app-debug.apk

# 查看 APK 大小
ls -lh app/build/outputs/apk/debug/app-debug.apk
```

### 测试 APK

1. **功能测试**
   - 输入日期和数字
   - 验证链接生成
   - 测试视频播放

2. **性能测试**
   - 监控内存使用
   - 检查 CPU 使用率
   - 测试长时间播放

3. **兼容性测试**
   - 在不同 Android 版本上测试
   - 在不同设备上测试
   - 测试屏幕方向切换

## 持续集成（CI）

项目包含 GitHub Actions 工作流，支持自动构建。工作流配置文件位于：

`.github/workflows/build-apk.yml`

### 工作流功能

- 自动在 push 和 pull request 时构建
- 生成 APK 并上传到 Artifacts
- 支持标签发布和自动 Release

### 自定义工作流

编辑 `.github/workflows/build-apk.yml` 以自定义构建流程。

## 总结

| 方式 | 优点 | 缺点 | 适用场景 |
|------|------|------|---------|
| GitHub Actions | 自动化、无需本地环境 | 需要 GitHub 账户 | 持续集成、自动发布 |
| Android Studio | 图形界面、易于调试 | 需要安装 Android Studio | 开发、测试 |
| 命令行 | 快速、灵活 | 需要配置环境 | 脚本化、自动化 |

选择最适合您的方式开始构建！
