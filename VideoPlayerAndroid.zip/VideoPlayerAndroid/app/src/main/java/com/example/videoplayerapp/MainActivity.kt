package com.example.videoplayerapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.videoplayerapp.databinding.ActivityMainBinding
import com.google.android.material.textfield.TextInputEditText

/**
 * 主屏幕 Activity
 * 用户在此输入日期和数字，然后播放视频
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 设置输入框监听
        setupInputListeners()

        // 设置播放按钮点击事件
        binding.playButton.setOnClickListener {
            handlePlayClick()
        }
    }

    /**
     * 设置输入框监听，实时显示链接预览
     */
    private fun setupInputListeners() {
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateUrlPreview()
            }
        }

        binding.yearInput.addTextChangedListener(textWatcher)
        binding.monthDayInput.addTextChangedListener(textWatcher)
        binding.numberInput.addTextChangedListener(textWatcher)
    }

    /**
     * 更新链接预览
     */
    private fun updateUrlPreview() {
        val year = binding.yearInput.text.toString().trim()
        val monthDay = binding.monthDayInput.text.toString().trim()
        val number = binding.numberInput.text.toString().trim()

        // 只有当所有输入都有效时才显示预览
        if (DateUtils.isValidYear(year) && 
            DateUtils.isValidMonthDay(monthDay) && 
            DateUtils.isValidNumber(number)) {
            val url = DateUtils.generateVideoUrl(year, monthDay, number)
            binding.urlPreviewText.text = url
            binding.urlPreviewCard.visibility = android.view.View.VISIBLE
        } else {
            binding.urlPreviewCard.visibility = android.view.View.GONE
        }
    }

    /**
     * 处理播放按钮点击
     */
    private fun handlePlayClick() {
        val year = binding.yearInput.text.toString().trim()
        val monthDay = binding.monthDayInput.text.toString().trim()
        val number = binding.numberInput.text.toString().trim()

        // 验证年份
        if (year.isEmpty()) {
            showError(getString(R.string.error_year_empty))
            return
        }
        if (!DateUtils.isValidYear(year)) {
            showError(getString(R.string.error_year_invalid))
            return
        }

        // 验证月日
        if (monthDay.isEmpty()) {
            showError(getString(R.string.error_month_day_empty))
            return
        }
        if (!DateUtils.isValidMonthDay(monthDay)) {
            showError(getString(R.string.error_month_day_invalid))
            return
        }

        // 验证数字
        if (number.isEmpty()) {
            showError(getString(R.string.error_number_empty))
            return
        }
        if (!DateUtils.isValidNumber(number)) {
            showError(getString(R.string.error_number_invalid))
            return
        }

        try {
            // 生成视频链接
            val videoUrl = DateUtils.generateVideoUrl(year, monthDay, number)

            // 启动播放器 Activity
            val intent = Intent(this, PlayerActivity::class.java).apply {
                putExtra("videoUrl", videoUrl)
                putExtra("year", year)
                putExtra("monthDay", monthDay)
                putExtra("number", number)
            }
            startActivity(intent)
        } catch (e: Exception) {
            showError(getString(R.string.error_generate_url))
        }
    }

    /**
     * 显示错误提示
     */
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
