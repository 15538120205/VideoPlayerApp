# Video Player - Android HLS 视频播放器

一个基于 Jetpack Media3 和 StyledPlayerView 的原生 Android 应用，支持通过输入日期和数字动态生成 HLS 视频链接并播放。

## 功能特性

**主屏幕**：用户可以输入年份（2位数字，如 26）、月日（MMDD 格式，例如 0202）和数字（3 位数字，例如 007），应用会自动验证输入并生成对应的 HLS 视频链接。链接中的日期会自动加一天（例如输入 26 0202 会生成 0203 的链接）。

**视频播放**：应用使用 Media3 的 PlayerView 播放 HLS 流媒体，提供完整的播放控制功能：
- 自动显示/隐藏的控制器（点击屏幕显示）
- 播放/暂停大按钮
- 可滑动拖动的 seek bar（进度条），支持快速 seek 和精确跳转
- 时间显示：当前 / 总时长
- 缓冲中 loading 动画
- 全屏按钮（支持横屏/竖屏切换）
- 快进/快退按钮

**错误处理**：应用提供完整的输入验证和错误提示，确保用户输入的有效性，并在播放失败时显示相应的错误信息。

**生命周期管理**：Activity 暂停/销毁时正确 pause/release player，恢复时续播。

## 项目结构

```
VideoPlayerApp/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/videoplayerapp/
│   │   │   │   ├── MainActivity.kt          # 主屏幕 Activity
│   │   │   │   ├── PlayerActivity.kt        # 播放器 Activity
│   │   │   │   └── DateUtils.kt            # 日期处理工具类
│   │   │   ├── res/
│   │   │   │   ├── layout/
│   │   │   │   │   ├── activity_main.xml    # 主屏幕布局
│   │   │   │   │   ├── activity_player.xml  # 播放器布局
│   │   │   │   │   └── custom_player_controls.xml  # 自定义播放器控制栏
│   │   │   │   ├── values/
│   │   │   │   │   ├── strings.xml          # 字符串资源
│   │   │   │   │   ├── colors.xml           # 颜色资源
│   │   │   │   │   └── styles.xml           # 样式资源
│   │   │   │   ├── drawable/                # 图形资源
│   │   │   │   ├── xml/                     # XML 资源
│   │   │   │   └── AndroidManifest.xml      # 清单文件
│   │   │   └── ...
│   │   └── ...
│   ├── build.gradle.kts                     # 模块级 Gradle 配置
│   └── proguard-rules.pro                   # ProGuard 规则
├── build.gradle.kts                         # 项目级 Gradle 配置
├── settings.gradle.kts                      # 项目设置
├── gradle.properties                        # Gradle 属性
└── README.md                                # 项目文档
```

## 技术栈

- **语言**：Kotlin
- **最低 API 级别**：24 (Android 7.0)
- **目标 API 级别**：34 (Android 14)
- **构建工具**：Gradle 8.1.0
- **视频播放**：
  - androidx.media3:media3-exoplayer:1.2.0
  - androidx.media3:media3-exoplayer-hls:1.2.0
  - androidx.media3:media3-ui:1.2.0
- **UI 框架**：Material Design 3
- **其他**：
  - AndroidX Core
  - AndroidX AppCompat
  - AndroidX ConstraintLayout
  - AndroidX Lifecycle

## 安装和构建

### 前置要求

- Android Studio 2022.1 或更高版本
- JDK 11 或更高版本
- Android SDK API 34

### 克隆项目

```bash
git clone <repository-url>
cd VideoPlayerApp
```

### 构建 APK

1. 打开 Android Studio
2. 选择 File → Open，选择项目目录
3. 等待 Gradle 同步完成
4. 选择 Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK 文件将生成在 `app/build/outputs/apk/debug/` 目录

### 在模拟器或设备上运行

1. 连接 Android 设备或启动模拟器
2. 选择 Run → Run 'app'
3. 选择目标设备
4. 应用将安装并启动

## 使用说明

### 播放视频

1. **打开应用**：启动应用后，您将看到主屏幕。

2. **输入年份**：在"年份"输入框中输入 2 位数字（例如 26 表示 2026 年）。

3. **输入月日**：在"月日 (MMDD)"输入框中输入月日，格式为 MMDD（例如 0202 表示 2 月 2 日）。

4. **输入数字**：在"数字 (3位)"输入框中输入 3 位数字（例如 007）。

5. **查看链接预览**：当输入有效时，应用会显示生成的视频链接预览。

6. **播放视频**：点击"播放视频"按钮，应用会生成完整的 HLS 链接并启动播放器。

7. **控制播放**：使用播放器的控制按钮进行播放、暂停、快进、快退、音量调节和全屏播放。

8. **返回**：点击播放器下方的"返回"按钮回到主屏幕。

### 链接生成规则

应用根据以下规则生成视频链接：

- **基础 URL**：`https://666.sybxpu.com/G{年份}{日期}{数字}/500kb/hls/index.m3u8`
- **日期处理**：输入的月日会自动加一天
- **示例**：输入年份 26、月日 0202 和数字 007，生成的链接为 `https://666.sybxpu.com/G260203007/500kb/hls/index.m3u8`

## 核心代码说明

### DateUtils.kt

提供日期处理和链接生成的工具函数：

```kotlin
// 验证输入格式
DateUtils.isValidYear(year)        // 验证年份
DateUtils.isValidMonthDay(monthDay) // 验证月日
DateUtils.isValidNumber(number)     // 验证数字

// 日期处理
DateUtils.addOneDay(monthDay)       // 日期加一天

// 链接生成
DateUtils.generateVideoUrl(year, monthDay, number)
```

### MainActivity.kt

主屏幕 Activity，处理用户输入和链接生成：

- `setupInputListeners()`：设置输入框监听，实时显示链接预览
- `updateUrlPreview()`：更新链接预览
- `handlePlayClick()`：处理播放按钮点击，验证输入并启动播放器

### PlayerActivity.kt

播放器 Activity，使用 Media3 播放 HLS 视频：

- `initializePlayer()`：初始化 ExoPlayer 和 HLS 媒体源
- `setupPlayerListener()`：设置播放器监听器，处理播放状态和错误
- `updateVideoInfo()`：显示视频信息
- `releasePlayer()`：释放播放器资源

## 播放器控制功能

### 自动显示/隐藏控制器

点击视频区域可显示/隐藏控制栏，5 秒无操作后自动隐藏。

### Seek Bar 拖动

- **左右滑动**：快速 seek，支持快进/快退
- **精确跳转**：点击进度条上的任意位置可跳转到该时间点
- **拖动进度条**：精确控制播放进度

### 播放/暂停

点击中心的播放/暂停按钮控制播放状态。

### 快进/快退

点击底部控制栏的快进/快退按钮，默认快进/快退 15 秒。

### 全屏播放

点击全屏按钮可进入全屏模式，支持自动旋转屏幕。

### 时间显示

显示当前播放时间和总时长，格式为 `MM:SS / MM:SS`。

## 错误处理

应用提供以下错误处理：

- **输入验证错误**：显示 Toast 提示用户输入格式不正确
- **网络错误**：播放失败时显示错误提示
- **播放器错误**：捕获 ExoPlayer 异常并显示错误信息

## 生命周期管理

- **onPause()**：暂停播放
- **onResume()**：恢复播放
- **onDestroy()**：释放播放器资源

## 屏幕方向

- **主屏幕**：竖屏锁定
- **播放器**：支持自动旋转（传感器控制）

## 权限

应用需要以下权限：

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

## 常见问题

**Q: 如何修改视频服务器地址？**
A: 编辑 `DateUtils.kt` 中的 `generateVideoUrl()` 函数，修改基础 URL。

**Q: 如何支持其他日期格式？**
A: 修改 `DateUtils.kt` 中的验证和处理函数。

**Q: 如何自定义播放器控制栏？**
A: 编辑 `custom_player_controls.xml` 布局文件。

**Q: 如何处理直播流？**
A: Media3 支持直播流，可以在 `PlayerActivity.kt` 中添加相应的处理逻辑。

## 性能优化

- 使用 Media3 的 HLS 自适应码率切换
- 正确的生命周期管理，避免内存泄漏
- 使用 ViewBinding 提高性能
- 异步网络请求处理

## 测试

### 单元测试

运行单元测试：

```bash
./gradlew test
```

### 集成测试

运行 Android 测试：

```bash
./gradlew connectedAndroidTest
```

## 许可证

本项目使用 MIT 许可证。

## 支持

如有问题或建议，请提交 Issue 或联系开发团队。

## 更新日志

### v1.0.0 (2026-02-02)

- 初始版本发布
- 实现主屏幕和视频播放功能
- 支持 HLS 流播放
- 完整的播放器控制功能
- 生命周期管理和错误处理
